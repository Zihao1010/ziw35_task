from ExtractGraph import ExtractGraph

g = ExtractGraph()
p = g.getProb('to','air')
print(p)